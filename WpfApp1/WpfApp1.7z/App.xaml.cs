﻿using System.Windows;

namespace Aida64Clone
{
    public partial class App : Application
    {
    }
}