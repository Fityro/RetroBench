﻿using System.Windows.Controls;

namespace Aida64Clone.Views
{
    public partial class ChartControl : UserControl
    {
        public ChartControl()
        {
            InitializeComponent();
        }
    }
}