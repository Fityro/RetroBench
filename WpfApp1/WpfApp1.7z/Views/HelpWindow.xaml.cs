﻿using System.Windows;

namespace Aida64Clone.Views
{
    public partial class HelpWindow : Window
    {
        public HelpWindow()
        {
            InitializeComponent();
        }
    }
}