﻿namespace WpfApp1.Models
{
    internal class TreeItem
    {
    }
}
