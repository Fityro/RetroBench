﻿namespace Aida64Clone.Models
{
    public class HelpItem
    {
        public string Title { get; set; }
        public string Description { get; set; }
    }
}