﻿namespace WpfApp1.ViewModels
{
    internal class HelpViewModel
    {
    }
}
